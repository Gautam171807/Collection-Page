const API_URL = "https://interveiw-mock-api.vercel.app/api/getProducts";
const productGrid = document.getElementById("product-grid");
const sortDropdown = document.getElementById("sort-dropdown");

productGrid.innerHTML = `<p class="animationBTN">Load Products</p>`;
let animationBTN = document.querySelector(".animationBTN");

animationBTN.addEventListener("click", () => {
  // Load products on page load
  animationBTN.classList.add("AnimationCircle");

  animationBTN.innerHTML = `
   <span id="ball-1" class="circle"></span>
  <span id="ball-2" class="circle"></span>
  <span id="ball-3" class="circle"></span>
  `;
  setTimeout(() => {
    document.querySelector(".AnimationCircle").remove();
    fetchProducts();
  }, 2000);
});

// Fetch products from API

async function fetchProducts() {
  try {
    const response = await fetch(API_URL);
    const data = await response.json();
    console.log(data);
    sortProducts(data.data);
    sortDropdown.addEventListener("change", () => sortProducts(data.data));
  } catch (error) {
    console.error("Error fetching products:", error);
  }
}

// Display products in the grid
function displayProducts(products) {
  productGrid.innerHTML = ""; // Clear grid
  products.forEach((product) => {
    const productCard = document.createElement("div");
    productCard.className = "product-card";

    productCard.innerHTML = `
      <img src="${product.product.image.src}" alt="${product.product.title}">
      <p>${product.product.title}</p>
      <p class="price">Rs. ${product.product.variants[0].price}</p>
      <button>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M10 2v4h4V2h4v4h2a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h2V2h4Zm-4 6v12h12V8H6Zm4 3h4v2h-4v-2Zm0 4h4v2h-4v-2Z"/></svg>
        Add to Cart
      </button>
    `;

    productGrid.appendChild(productCard);
  });
}

function sortProducts(products) {
  const sortValue = sortDropdown.value;

  let sortedProducts;
  if (sortValue === "low-to-high") {
    sortedProducts = [...products].sort((a, b) => {
      return (
        parseFloat(a.product.variants[0].price) -
        parseFloat(b.product.variants[0].price)
      );
    });
  } else if (sortValue === "high-to-low") {
    sortedProducts = [...products].sort((a, b) => {
      return (
        parseFloat(b.product.variants[0].price) -
        parseFloat(a.product.variants[0].price)
      );
    });
  } else {
    console.log(products);
    sortedProducts = products; // Default order
  }

  // Redisplay the sorted products
  displayProducts(sortedProducts);
}
